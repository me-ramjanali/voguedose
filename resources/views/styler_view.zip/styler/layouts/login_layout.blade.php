<!-- includes header file -->
@include('styler.parts.header')
<!-- Main Body content starts here -->
@yield('content')
<!-- # wrapper -->
<!-- includes footer file -->
@include('styler.parts.footer')